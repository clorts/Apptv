package com.meusistema.tv;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {

    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        web.setBackgroundColor(0xFF8B0000);
        web.setWebViewClient(new WebViewClient());

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);

        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("file:///android_asset/launcher.html");

        setContentView(web);
        web.requestFocus();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        // Apertou Home de novo: volta pro launcher
        web.loadUrl("file:///android_asset/launcher.html");
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    @Override
    public void onBackPressed() {
        // Tela inicial não pode fechar. Só volta se estiver num site.
        if (web.canGoBack()) {
            web.goBack();
        } else {
            web.loadUrl("file:///android_asset/launcher.html");
        }
    }

    private class Bridge {
        @JavascriptInterface
        public void abrir(final String pkg) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    abrirApp(pkg);
                }
            });
        }
    }

    private void abrirApp(String pkg) {
        try {
            Intent i = getPackageManager().getLeanbackLaunchIntentForPackage(pkg);
            if (i == null) {
                i = getPackageManager().getLaunchIntentForPackage(pkg);
            }
            if (i == null && pkg.contains("settings")) {
                i = new Intent(Settings.ACTION_SETTINGS);
            }
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } else {
                Toast.makeText(this, "App não instalado: " + pkg, Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Não deu pra abrir: " + pkg, Toast.LENGTH_LONG).show();
        }
    }
}
